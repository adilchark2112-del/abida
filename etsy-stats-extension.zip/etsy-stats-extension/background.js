const ETSY_API_BASE = "https://openapi.etsy.com/v3/application";
const REFRESH_INTERVAL_MINUTES = 5;

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("refreshData", { periodInMinutes: REFRESH_INTERVAL_MINUTES });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "refreshData") {
    refreshEtsyData();
  }
});

async function refreshEtsyData() {
  const config = await chrome.storage.local.get(["apiKey", "shopId", "accessToken"]);
  if (!config.apiKey || !config.shopId) return;

  try {
    const receipts = await fetchReceipts(config);
    const listings = await fetchListings(config);
    const now = Date.now();

    const salesData = processReceipts(receipts, now);
    const listingsData = processListings(listings);

    await chrome.storage.local.set({
      salesData,
      listingsData,
      lastUpdated: now,
      receiptsRaw: receipts.slice(0, 100)
    });

    const lastSaleDiff = salesData.lastSaleTime ? (now - salesData.lastSaleTime) / 1000 / 60 : null;
    if (lastSaleDiff !== null && lastSaleDiff < 6) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon48.png",
        title: "New Etsy Sale!",
        message: `You just made a sale on Etsy 🎉`
      });
    }
  } catch (e) {
    console.error("Etsy refresh error:", e);
  }
}

async function fetchReceipts(config) {
  const sevenDaysAgo = Math.floor((Date.now() - 7 * 24 * 60 * 60 * 1000) / 1000);
  const url = `${ETSY_API_BASE}/shops/${config.shopId}/receipts?limit=100&min_created=${sevenDaysAgo}&was_paid=true`;

  const res = await fetch(url, {
    headers: {
      "x-api-key": config.apiKey,
      "Authorization": `Bearer ${config.accessToken}`
    }
  });

  if (!res.ok) throw new Error(`Receipts API error: ${res.status}`);
  const data = await res.json();
  return data.results || [];
}

async function fetchListings(config) {
  const url = `${ETSY_API_BASE}/shops/${config.shopId}/listings/active?limit=100&includes[]=Images&includes[]=Stats`;

  const res = await fetch(url, {
    headers: {
      "x-api-key": config.apiKey,
      "Authorization": `Bearer ${config.accessToken}`
    }
  });

  if (!res.ok) throw new Error(`Listings API error: ${res.status}`);
  const data = await res.json();
  return data.results || [];
}

function processReceipts(receipts, now) {
  const oneHourAgo = now / 1000 - 3600;
  const oneDayAgo = now / 1000 - 86400;
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const startOfDayTs = startOfDay.getTime() / 1000;
  const startOfWeek = new Date();
  startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  const startOfWeekTs = startOfWeek.getTime() / 1000;

  let salesThisHour = 0;
  let salesToday = 0;
  let salesThisWeek = 0;
  let salesLast24h = 0;
  let revenueToday = 0;
  let revenueThisWeek = 0;
  let lastSaleTime = null;
  const productSales = {};

  receipts.forEach(receipt => {
    const createdTs = receipt.create_timestamp || receipt.created_timestamp;
    const amount = parseFloat(receipt.grandtotal?.amount || 0) / (receipt.grandtotal?.divisor || 100);

    if (!lastSaleTime || createdTs > lastSaleTime) {
      lastSaleTime = createdTs;
    }

    if (createdTs >= oneHourAgo) salesThisHour++;
    if (createdTs >= oneDayAgo) salesLast24h++;
    if (createdTs >= startOfDayTs) {
      salesToday++;
      revenueToday += amount;
    }
    if (createdTs >= startOfWeekTs) {
      salesThisWeek++;
      revenueThisWeek += amount;
    }

    (receipt.transactions || []).forEach(tx => {
      const title = tx.title || "Unknown Product";
      const listingId = tx.listing_id;
      const key = `${listingId}`;
      if (!productSales[key]) {
        productSales[key] = { title, listingId, count: 0, revenue: 0, lastSale: null };
      }
      productSales[key].count++;
      productSales[key].revenue += parseFloat(tx.price?.amount || 0) / (tx.price?.divisor || 100);
      if (!productSales[key].lastSale || createdTs > productSales[key].lastSale) {
        productSales[key].lastSale = createdTs;
      }
    });
  });

  const topProducts = Object.values(productSales)
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  return {
    salesThisHour,
    salesToday,
    salesThisWeek,
    salesLast24h,
    revenueToday: revenueToday.toFixed(2),
    revenueThisWeek: revenueThisWeek.toFixed(2),
    lastSaleTime: lastSaleTime ? lastSaleTime * 1000 : null,
    topProducts,
    totalReceipts: receipts.length
  };
}

function processListings(listings) {
  return listings.map(l => ({
    id: l.listing_id,
    title: l.title,
    views: l.views || 0,
    quantity: l.quantity,
    price: parseFloat(l.price?.amount || 0) / (l.price?.divisor || 100),
    image: l.images?.[0]?.url_75x75 || null,
    createdAt: l.creation_timestamp,
    url: l.url
  })).sort((a, b) => b.views - a.views);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "REFRESH_NOW") {
    refreshEtsyData().then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
