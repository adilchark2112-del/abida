let lastSaleInterval = null;

document.addEventListener("DOMContentLoaded", async () => {
  await init();
  setupTabs();
  setupButtons();
});

async function init() {
  const config = await chrome.storage.local.get(["apiKey", "shopId", "accessToken"]);

  if (!config.apiKey || !config.shopId || !config.accessToken) {
    showScreen("setup");
    return;
  }

  const stored = await chrome.storage.local.get(["salesData", "listingsData", "lastUpdated"]);

  if (stored.salesData) {
    showScreen("dashboard");
    renderDashboard(stored.salesData, stored.listingsData, stored.lastUpdated);
  } else {
    showScreen("loading");
    const ok = await triggerRefresh();
    if (!ok) {
      showScreen("setup");
    } else {
      const fresh = await chrome.storage.local.get(["salesData", "listingsData", "lastUpdated"]);
      showScreen("dashboard");
      renderDashboard(fresh.salesData, fresh.listingsData, fresh.lastUpdated);
    }
  }
}

function showScreen(name) {
  document.getElementById("setup-screen").style.display = name === "setup" ? "block" : "none";
  document.getElementById("loading-screen").style.display = name === "loading" ? "flex" : "none";
  document.getElementById("dashboard").style.display = name === "dashboard" ? "block" : "none";
}

function setupTabs() {
  document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
    });
  });
}

function setupButtons() {
  document.getElementById("refreshBtn").addEventListener("click", async () => {
    document.getElementById("refreshBtn").textContent = "⏳";
    const ok = await triggerRefresh();
    document.getElementById("refreshBtn").textContent = "🔄";
    if (ok) {
      const fresh = await chrome.storage.local.get(["salesData", "listingsData", "lastUpdated"]);
      renderDashboard(fresh.salesData, fresh.listingsData, fresh.lastUpdated);
    }
  });

  document.getElementById("settingsBtn").addEventListener("click", () => {
    showScreen("setup");
    restoreConfig();
  });

  document.getElementById("saveConfigBtn").addEventListener("click", saveConfig);
}

async function restoreConfig() {
  const config = await chrome.storage.local.get(["apiKey", "shopId", "accessToken"]);
  if (config.apiKey) document.getElementById("apiKeyInput").value = config.apiKey;
  if (config.accessToken) document.getElementById("accessTokenInput").value = config.accessToken;
  if (config.shopId) document.getElementById("shopIdInput").value = config.shopId;
}

async function saveConfig() {
  const apiKey = document.getElementById("apiKeyInput").value.trim();
  const accessToken = document.getElementById("accessTokenInput").value.trim();
  const shopId = document.getElementById("shopIdInput").value.trim();
  const errEl = document.getElementById("errorMsg");

  if (!apiKey || !accessToken || !shopId) {
    errEl.textContent = "⚠️ يرجى ملء جميع الحقول";
    errEl.style.display = "block";
    return;
  }

  errEl.style.display = "none";
  await chrome.storage.local.set({ apiKey, accessToken, shopId });

  showScreen("loading");
  const ok = await triggerRefresh();

  if (ok) {
    const fresh = await chrome.storage.local.get(["salesData", "listingsData", "lastUpdated"]);
    showScreen("dashboard");
    renderDashboard(fresh.salesData, fresh.listingsData, fresh.lastUpdated);
  } else {
    showScreen("setup");
    errEl.textContent = "❌ فشل الاتصال. تحقق من بيانات API وحاول مرة أخرى.";
    errEl.style.display = "block";
  }
}

async function triggerRefresh() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "REFRESH_NOW" }, (res) => {
      if (chrome.runtime.lastError) resolve(false);
      else resolve(res?.ok === true);
    });
  });
}

function renderDashboard(salesData, listingsData, lastUpdated) {
  if (!salesData) return;

  // Status
  const dot = document.getElementById("statusDot");
  dot.className = "status-dot";
  document.getElementById("statusText").textContent = "متصل • يتحدث كل 5 دقائق";

  if (lastUpdated) {
    const mins = Math.floor((Date.now() - lastUpdated) / 60000);
    document.getElementById("lastUpdatedText").textContent =
      mins < 1 ? "الآن" : `منذ ${mins} دقيقة`;
  }

  // Sales numbers
  document.getElementById("salesHour").textContent = salesData.salesThisHour;
  document.getElementById("sales24h").textContent = salesData.salesLast24h;
  document.getElementById("salesToday").textContent = salesData.salesToday;
  document.getElementById("salesWeek").textContent = salesData.salesThisWeek;
  document.getElementById("revenueToday").textContent = "$" + salesData.revenueToday;
  document.getElementById("revenueWeek").textContent = "$" + salesData.revenueWeek;

  // Last sale timer
  startLastSaleTimer(salesData.lastSaleTime);

  // Top products
  renderTopProducts(salesData.topProducts);

  // Top views
  if (listingsData) renderTopViews(listingsData);
}

function startLastSaleTimer(lastSaleTime) {
  if (lastSaleInterval) clearInterval(lastSaleInterval);

  function update() {
    const timerEl = document.getElementById("lastSaleTimer");
    const agoEl = document.getElementById("lastSaleAgo");

    if (!lastSaleTime) {
      timerEl.textContent = "--";
      agoEl.textContent = "لا توجد مبيعات بعد";
      return;
    }

    const diff = Math.floor((Date.now() - lastSaleTime) / 1000);
    const h = Math.floor(diff / 3600);
    const m = Math.floor((diff % 3600) / 60);
    const s = diff % 60;

    timerEl.textContent =
      String(h).padStart(2, "0") + ":" +
      String(m).padStart(2, "0") + ":" +
      String(s).padStart(2, "0");

    if (diff < 60) agoEl.textContent = "منذ ثوانٍ";
    else if (diff < 3600) agoEl.textContent = `منذ ${m} دقيقة`;
    else if (diff < 86400) agoEl.textContent = `منذ ${h} ساعة`;
    else agoEl.textContent = `منذ ${Math.floor(diff / 86400)} يوم`;
  }

  update();
  lastSaleInterval = setInterval(update, 1000);
}

function renderTopProducts(products) {
  const container = document.getElementById("topProductsList");
  if (!products || products.length === 0) {
    container.innerHTML = '<div class="no-data">لا توجد مبيعات هذا الأسبوع</div>';
    return;
  }

  container.innerHTML = products.map((p, i) => `
    <div class="product-row">
      <div class="product-rank">#${i + 1}</div>
      <div class="product-img">
        ${p.image ? `<img src="${p.image}" alt="">` : "🛍️"}
      </div>
      <div class="product-info">
        <div class="product-title">${escapeHtml(p.title)}</div>
        <div class="product-meta">
          $${p.revenue.toFixed(2)} إيرادات
          ${p.lastSale ? " • " + timeAgoAr(p.lastSale * 1000) : ""}
        </div>
      </div>
      <div class="product-sales">
        <div class="product-sales-num">${p.count}</div>
        <div class="product-sales-label">مبيعة</div>
      </div>
    </div>
  `).join("");
}

function renderTopViews(listings) {
  const container = document.getElementById("topViewsList");
  if (!listings || listings.length === 0) {
    container.innerHTML = '<div class="no-data">لا توجد بيانات مشاهدات</div>';
    return;
  }

  const maxViews = Math.max(...listings.slice(0, 10).map(l => l.views), 1);

  container.innerHTML = listings.slice(0, 10).map((l, i) => `
    <div class="listing-row">
      <div class="product-img" style="flex-shrink:0">
        ${l.image ? `<img src="${l.image}" alt="">` : "🛍️"}
      </div>
      <div style="flex:1; min-width:0">
        <div class="product-title">${escapeHtml(l.title)}</div>
        <div style="margin-top:4px">
          <div class="views-bar-wrap">
            <div class="views-bar" style="width:${Math.round(l.views / maxViews * 100)}%"></div>
          </div>
        </div>
      </div>
      <div class="listing-views">${l.views.toLocaleString()}</div>
    </div>
  `).join("");
}

function timeAgoAr(ts) {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 60) return "منذ ثوانٍ";
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} د`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} س`;
  return `منذ ${Math.floor(diff / 86400)} يوم`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
