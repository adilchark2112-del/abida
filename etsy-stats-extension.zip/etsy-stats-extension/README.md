# 📊 Etsy Stats Dashboard — Chrome Extension

أداة احترافية لمتابعة إحصائيات متجرك على Etsy في الوقت الفعلي مباشرةً من المتصفح.

---

## ✅ الميزات

| الميزة | التفاصيل |
|--------|----------|
| 🕐 مبيعات هذه الساعة | عدد المبيعات في آخر 60 دقيقة |
| 📅 مبيعات اليوم | منذ منتصف الليل حتى الآن |
| 📅 آخر 24 ساعة | آخر 24 ساعة متحركة |
| 📆 مبيعات الأسبوع | آخر 7 أيام |
| ⏱ عداد آخر مبيعة | عداد يعمل بالثانية منذ آخر بيع |
| 💰 الإيرادات | إيرادات اليوم والأسبوع بالدولار |
| 🏆 أعلى المنتجات | ترتيب المنتجات حسب المبيعات |
| 👁 المشاهدات | المنتجات الأعلى مشاهدة |
| 🔄 تحديث تلقائي | كل 5 دقائق |

---

## 🔧 خطوات التثبيت

### الخطوة 1 — تثبيت الأداة في Chrome

1. افتح Chrome وانتقل إلى: `chrome://extensions/`
2. فعّل **Developer Mode** (الزاوية اليمنى العليا)
3. اضغط **Load unpacked**
4. اختر مجلد `etsy-stats-extension`
5. ستظهر الأداة في شريط الأدوات 🎉

---

### الخطوة 2 — الحصول على Etsy API Key

1. اذهب إلى: https://www.etsy.com/developers/register
2. سجّل دخولك بحساب Etsy
3. اضغط **Create a New App**
4. املأ البيانات:
   - **App Name**: My Stats Dashboard
   - **What will you build**: Other
5. ستحصل على **Keystring** — هذا هو API Key الخاص بك

---

### الخطوة 3 — الحصول على Access Token (OAuth2)

هذا الجزء يتطلب خطوات تقنية بسيطة:

#### الطريقة السريعة (للاستخدام الشخصي):

1. في إعدادات تطبيقك على Etsy Developers، انسخ:
   - `Client ID` (نفس الـ API Key)
   - `Shared Secret`

2. افتح هذا الرابط في المتصفح (استبدل `YOUR_API_KEY`):
```
https://www.etsy.com/oauth/connect?response_type=code&redirect_uri=https://localhost&scope=transactions_r%20listings_r&client_id=YOUR_API_KEY&state=superstate&code_challenge=DSWlX9KsEFIBl9nKkGilTQFJGbN4RyHxFi_IFUYaHTc&code_challenge_method=S256
```

3. اضغط **Allow Access** — ستُعاد التوجيه إلى localhost
4. من URL الجديد، انسخ قيمة `code=XXXXX`

5. في Terminal أو PowerShell، نفّذ:
```bash
curl -X POST "https://api.etsy.com/v3/public/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code&client_id=YOUR_API_KEY&redirect_uri=https://localhost&code=THE_CODE_YOU_COPIED&code_verifier=YOUR_VERIFIER"
```

6. ستحصل على `access_token` — انسخه

> 💡 **ملاحظة**: للتبسيط، يمكن استخدام Etsy's Playground Tool على موقع Developers مباشرةً للحصول على Token للاختبار.

---

### الخطوة 4 — الحصول على Shop ID

بعد الحصول على Access Token، نفّذ:
```bash
curl "https://openapi.etsy.com/v3/application/users/me/shops" \
  -H "x-api-key: YOUR_API_KEY" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```
ستجد `shop_id` في الرد.

---

### الخطوة 5 — ربط الأداة

1. افتح الأداة من شريط Chrome
2. أدخل:
   - **API Key**
   - **Access Token**  
   - **Shop ID**
3. اضغط **حفظ والبدء** ✅

---

## 🔄 التحديث التلقائي

- تتحدث البيانات تلقائيًا كل **5 دقائق**
- يمكن التحديث اليدوي بأي وقت عبر زر 🔄

---

## ⚠️ ملاحظات مهمة

- **Access Token تنتهي صلاحيته** — ستحتاج لتجديده كل 3 أيام (أو تطبيق Refresh Token)
- البيانات تُخزن محليًا في متصفحك فقط — لا ترسل لأي خادم خارجي
- تعمل الأداة فقط مع بيانات **متجرك الخاص** — بيانات المنافسين غير متاحة عبر Etsy API

---

## 📁 هيكل الملفات

```
etsy-stats-extension/
├── manifest.json      ← إعدادات الأداة
├── popup.html         ← واجهة المستخدم
├── popup.js           ← منطق العرض
├── background.js      ← جلب البيانات من API
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
